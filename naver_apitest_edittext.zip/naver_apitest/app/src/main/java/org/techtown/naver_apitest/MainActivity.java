package org.techtown.naver_apitest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.content.AsyncTaskLoader;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    ImageView imgview;
    TextView response_text;
    Button btn;
    GridView board;
    EditText search_query;

    Bitmap image;
    ArrayList<Bitmap> imgList = new ArrayList<>();
    ArrayList<Integer> answerList = new ArrayList<>();
    ArrayList<Integer> board_bit = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgview = findViewById(R.id.imageView);
        response_text = findViewById(R.id.textView);
        btn = findViewById(R.id.button2);
        board = findViewById(R.id.gridview);
        search_query = findViewById(R.id.edittext);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String query = search_query.getText().toString();

                //get image data from naver image searching
                ImageData imagedata = new ImageData(query);
                try {
                    imagedata.setimg();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Bitmap pre_Image=imagedata.getImg();

                //resize img data
                ImgEditor editor = new ImgEditor(pre_Image);
                image = editor.resize();

                //to black and white image
                image = editor.grayScale();

                //cut image
                editor.cutImg();
                imgList = editor.getImgList();

                //make 20x20 black-white list
                answerList = editor.getBitList();
                //System.out.println(answerList.get(258));

                // set Clue numbers
                SetClue clue = new SetClue(answerList);
                board_bit = clue.getClueList();

                board.setNumColumns(clue.getWidth());

                System.out.println("boardbit size: "+String.valueOf(board_bit.size()));
                System.out.println("width: "+String.valueOf(clue.getWidth()));
                GridAdapter adapter = new GridAdapter(board_bit, clue.getWidth());
                board.setAdapter(adapter);


                imgview.setImageBitmap(image);
                response_text.setText(image.getHeight()+"  "+image.getWidth());

            }
        });

    }

}
