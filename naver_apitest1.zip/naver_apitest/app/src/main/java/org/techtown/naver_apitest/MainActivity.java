package org.techtown.naver_apitest;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    TextView test_url;
    ImageView img;
    TextView response_text;
    Button btn;
    String query;
    String img_link;
    final String ClientId = "olbjaQTrUKUCmk9JaUGs";
    final String ClientSecret = "mMhcq4yzaq";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        test_url = findViewById(R.id.textView2);
        img = findViewById(R.id.imageView);
        response_text = findViewById(R.id.textView);
        btn = findViewById(R.id.button);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //response_text.setText("haha");
                OkHttpClient client = new OkHttpClient();

                query = "cat";

                HttpUrl.Builder urlBuilder = HttpUrl.parse("https://openapi.naver.com/v1/search/image").newBuilder();
                urlBuilder.addQueryParameter("query", query);
                urlBuilder.addQueryParameter("display", "10");

                String url = urlBuilder.build().toString();
                test_url.setText(url);

                Request req = new Request.Builder()
                        .url(url)
                        .header("X-Naver-Client-Id", ClientId)
                        .addHeader("X-Naver-Client-Secret", ClientSecret)
                        .build();

                client.newCall(req).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        final String myResponse = response.body().string();


                        Gson gson = new GsonBuilder().create();
                        final DataModel data = gson.fromJson(myResponse, DataModel.class);

                        img_link = data.items.get(0).getLink();

                        URL url = new URL(img_link);
                        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                        connection.setDoInput(true);
                        connection.connect();
                        InputStream input = connection.getInputStream();
                        final Bitmap bit_img = BitmapFactory.decodeStream(input);

                        MainActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                response_text.setText(data.items.get(0).getLink());
                                img.setImageBitmap(bit_img);
//                                System.out.println(data.getDisplay());
//                                System.out.println(data.getTotal());
//                                System.out.println(data.items.get(0).getLink());

                            }
                        });

                    }
                });
            }
        });

    }
}
